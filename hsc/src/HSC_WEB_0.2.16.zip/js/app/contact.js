Hsc.ContactController = Ember.ObjectController.extend({
    needs:["application"]
});

