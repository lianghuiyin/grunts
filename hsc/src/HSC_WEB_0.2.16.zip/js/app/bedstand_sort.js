Hsc.BedstandSort = DS.Model.extend({
    bedstand_id: DS.attr('number'),
    is_reverse: DS.attr('boolean')
});
